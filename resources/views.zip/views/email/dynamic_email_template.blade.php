<h3>Name: {{$data['name']}}</h3>
<h5>subject: {{$data['subject']}}</h5>
<p>Email: {{$data['email']}}</p>
<br>
<p>{{$data['message']}}</p>